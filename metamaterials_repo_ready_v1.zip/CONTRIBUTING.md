See CONTRIBUTING guidelines in project documentation.
