#!/bin/bash
# Use: ./scripts/setup_repo.sh <git-remote-url>
